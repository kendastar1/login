/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quizvectores;




/**
 *
 * @author ESTUDIANTE19
 */
public class QuizVectores {

    public static void main(String[] args) {
        
        System.out.println("multiplos de 5");
        int vector1[] = null;
        metodos.multiplos(vector1);
        
        
        

        
    }
}
