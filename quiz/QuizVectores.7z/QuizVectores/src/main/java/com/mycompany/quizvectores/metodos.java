/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quizvectores;

import java.util.Random;

/**
 *
 * @author ESTUDIANTE19
 */
public class metodos {
    
    public static void multiplos(int vector[]){
        int v5 = 0;
        int v3 = 0;
        vector = new int[10];
        Random Random = new Random();
        
        for(int a = 0; a < vector.length;a++){
            vector[a] = Random.nextInt(141) + 10;
            System.out.println(vector[a]);
            if (vector[a] % 5 == 0){
                v5 += v5 + vector[a];
                
            }
            
            if (vector[a] % 3 == 0){
                v3 += v3 + vector[a];
                
            }
        }
        metodos.resultado(v5,v3);
  
 
    }
    
   
   public static void resultado(int v5,int v3){
        
        System.out.println("la suma de los vectores es " + v5);
        System.out.println("multiplos de 3");
        System.out.println("la suma de los vectores es " + v3);
        
    }
    
}
