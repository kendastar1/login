/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quizde50a100;




/**
 *
 * @author ESTUDIANTE19
 */
public class Quizde50a100 {

    public static void main(String[] args) {
        int vector [] = null;
        int multiplicacion = 0;
        metodos.entrada(vector,multiplicacion);
        System.out.println("ha finalizado");
       
      
    }
}
