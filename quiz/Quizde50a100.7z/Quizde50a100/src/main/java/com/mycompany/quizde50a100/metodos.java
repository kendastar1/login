/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.quizde50a100;

import java.util.Random;

/**
 *
 * @author ESTUDIANTE19
 */
public class metodos {
    public static void entrada(int vector[],int multiplicacion1){
          vector = new int[10];
            Random ramdon = new Random();
        for(int a = 0; a < vector.length;a++){
            vector[a] = ramdon.nextInt(50) + 50;
            System.out.println(vector[a]);
            multiplicacion1 = (int) (vector[a] * 0.5);
            metodos.resultado(multiplicacion1);
            
        }
        
        
          
    }
    public static void resultado(int multiplicacion){
        System.out.println("la multiplicacion de 0.5 es de " + multiplicacion);
    }
}
